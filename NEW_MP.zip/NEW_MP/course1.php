<?php
session_start();

// Enable error reporting to troubleshoot issues
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Check if faculty data exists in session
$facultyData = $_SESSION['facultyData'] ?? null;

$connection = mysqli_connect("localhost", "root", "", "new_pro");

if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}

// Use default faculty ID if none is available in the session
$faculty_id = $facultyData['id'] ?? 1;

// Fetch faculty data based on faculty ID
$query = "SELECT name, course1, syllabus1, labmanual1, questionbank1, unit1_file1, unit2_file1, unit3_file1, unit4_file1, unit5_file1 FROM faculty_page WHERE id = ?";
$stmt = $connection->prepare($query);
$stmt->bind_param("i", $faculty_id);
$stmt->execute();
$result = $stmt->get_result();

// Check if faculty data was found
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    
    // Assign fetched data to variables
    $name = $row['name'] ?? 'Guest Faculty';
    $course1 = $row['course1'];
    $syllabus1 = $row['syllabus1'];
    $labmanual1 = $row['labmanual1'];
    $questionbank1 = $row['questionbank1'];
    $unit1_file1 = $row['unit1_file1'];
    $unit2_file1 = $row['unit2_file1'];
    $unit3_file1 = $row['unit3_file1'];
    $unit4_file1 = $row['unit4_file1'];
    $unit5_file1 = $row['unit5_file1'];
} else {
    echo "No data found.";
    exit();
}

// Close the statement and connection
$stmt->close();
$connection->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Faculty Dashboard</title>
    <link href="" rel="stylesheet">
    <style type="text/css">
        * {
            padding: 0;
            margin: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif, 'Times New Roman', Times, serif;
            background-color: #f4f4f4;
            background-image: linear-gradient(rgba(0, 0, 0, 0.55), rgba(0, 0, 0, 0.55)), url(background.jpg);
            background-size: cover;
            background-position: center;
            color: #fff;
            margin: 0;
            padding: 0;
        }

        .container {
            max-width: 1000px;
            width: 90%;
            margin: 50px auto;
            padding: 40px;
            border-radius: 10px;
            background: rgba(255, 255, 255, 0.1);
            backdrop-filter: blur(10px);
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.2);
            color: #fff;
        }

        h2, h3 {
            text-align: center;
            margin-bottom: 30px;
            color: white;
        }

        h2 {
            font-size: 28px;
            color: #fff;
        }

        h3 {
            font-size: 22px;
            color: white;
        }

        .resource-container {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }

        .resource-card {
            background-color: #ffffff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            transition: transform 0.2s ease, box-shadow 0.3s ease;
        }

        .resource-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.15);
        }

        .resource-card p {
            font-size: 16px;
            color: #666;
            margin: 0 0 5px;
        }

        .resource-card a {
            color: darkgreen;
            font-weight: bold;
            text-decoration: none;
            transition: color 0.2s ease;
        }

        .resource-card a:hover {
            color: #0056b3;
        }

        .section-title {
            font-size: 24px;
            color: white;
            margin-top: 40px;
            text-align: center;
        }

        /* Additional form styles for consistency with the page */
        .form-control {
            padding: 15px;
            border-radius: 5px;
            border: 1px solid #ccc;
            width: 100%;
            font-size: 16px;
        }

        .form-control:focus {
            border-color: #fff;
            box-shadow: 0 0 5px rgba(0, 123, 255, 0.5);
        }

        .btn-primary {
            background-color: #007bff;
            color: white;
            width: 100%;
            padding: 10px;
            border: none;
            border-radius: 5px;
            font-size: 18px;
            cursor: pointer;
        }

        .btn-primary:hover {
            background-color: #0056b3;
        }

        .courses-section {
            margin-top: 30px;
            padding: 20px;
            background-color: rgba(255, 255, 255, 0.1);
            border-radius: 10px;
        }

        .courses-row {
            display: flex;
            justify-content: space-between;
            gap: 20px;
        }

        .courses-row .form-group {
            flex: 1;
        }

        .courses-row .form-control {
            width: 275px;
        }

        .card-title{
                color: darkblue;
            }

        /* Media Queries for mobile responsiveness */
        @media (max-width: 768px) {
            body{
            	margin-top: 20px;
            }
            .container {
                width: 95%;
                padding: 20px;

            }

            .tab-button {
        width: 100%;
        margin-bottom: 10px;
        margin-left: 20px; 
			}
            .resource-container {
                flex-direction: column;
            }

            .resource-card {
                padding: 15px;
            }

            h2 {
                font-size: 24px;
                color: white;
            }

            h3 {
                font-size: 20px;

            }

            .resource-card a {
                font-size: 14px;
            }
        }

        @media (max-width: 576px) {
            .container {
                padding: 15px;
                width: 100%;
            }

            h2 {
                font-size: 20px;
            }

            h3 {
                font-size: 18px;
                color: white;
            }

            .resource-card p {
                font-size: 14px;
            }

            .section-title {
                font-size: 20px;
                color: white;
            }
            .card-title{
                color: darkblue;
            }
        }
    </style>
</head>
<body>
<div class="container">
    <h2><?php echo htmlspecialchars($course1); ?> Materials</h2>
    
    <div class="resource-container">
        <!-- Syllabus -->
        <div class="resource-card">
            <h3 class="card-title">Syllabus</h3>
            <p>
                <?php if ($syllabus1): ?>
                    <a href="<?php echo htmlspecialchars($syllabus1); ?>" target="_blank">View Syllabus</a>
                <?php else: ?>
                    Not uploaded
                <?php endif; ?>
            </p>
        </div>

        <!-- Lab Manual -->
        <div class="resource-card">
            <h3 class="card-title">Lab Manual</h3>
            <p>
                <?php if ($labmanual1): ?>
                    <a href="<?php echo htmlspecialchars($labmanual1); ?>" target="_blank">View Lab Manual</a>
                <?php else: ?>
                    Not uploaded
                <?php endif; ?>
            </p>
        </div>

        <!-- Question Bank -->
        <div class="resource-card">
            <h3 class="card-title">Question Bank</h3>
            <p>
                <?php if ($questionbank1): ?>
                    <a href="<?php echo htmlspecialchars($questionbank1); ?>" target="_blank">View Question Bank</a>
                <?php else: ?>
                    Not uploaded
                <?php endif; ?>
            </p>
        </div>

        <!-- Unit Files -->
        <h2 class="section-title">Unit Files</h2>
        
        <!-- Unit 1 -->
        <div class="resource-card">
           <h3 class="card-title">Unit 1</h3>
            <p>
                <?php if ($unit1_file1): ?>
                    <a href="<?php echo htmlspecialchars($unit1_file1); ?>" target="_blank">View Unit 1</a>
                <?php else: ?>
                    Not uploaded
                <?php endif; ?>
            </p>
        </div>

        <!-- Unit 2 -->
        <div class="resource-card">
            <h3 class="card-title">Unit 2</h3>
            <p>
                <?php if ($unit2_file1): ?>
                    <a href="<?php echo htmlspecialchars($unit2_file1); ?>" target="_blank">View Unit 2</a>
                <?php else: ?>
                    Not uploaded
                <?php endif; ?>
            </p>
        </div>

        <!-- Unit 3 -->
        <div class="resource-card">
            <h3 class="card-title">Unit 3</h3>
            <p>
                <?php if ($unit3_file1): ?>
                    <a href="<?php echo htmlspecialchars($unit3_file1); ?>" target="_blank">View Unit 3</a>
                <?php else: ?>
                    Not uploaded
                <?php endif; ?>
            </p>
        </div>

        <!-- Unit 4 -->
        <div class="resource-card">
            <h3 class="card-title">Unit 4</h3>
            <p>
                <?php if ($unit4_file1): ?>
                    <a href="<?php echo htmlspecialchars($unit4_file1); ?>" target="_blank">View Unit 4</a>
                <?php else: ?>
                    Not uploaded
                <?php endif; ?>
            </p>
        </div>

        <!-- Unit 5 -->
        <div class="resource-card">
            <h3 class="card-title">Unit 5</h3>
            <p>
                <?php if ($unit5_file1): ?>
                    <a href="<?php echo htmlspecialchars($unit5_file1); ?>" target="_blank">View Unit 5</a>
                <?php else: ?>
                    Not uploaded
                <?php endif; ?>
            </p>
        </div>
    </div>
</div>
</body>
</html>

</html>
