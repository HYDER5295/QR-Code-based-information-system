<?php
session_start();

if (!isset($_SESSION['facultyData'])) {
    header("Location: login.php");
    exit();
}

$facultyData = $_SESSION['facultyData'];
$faculty_id = $facultyData['id'];

$connection = mysqli_connect("localhost", "root", "", "new_pro");

if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}

// Fetch faculty details using the faculty ID from the session
$faculty_id = $facultyData['id']; // Assuming you have an 'id' field to identify the faculty
$query = "SELECT name, qualification, department, course1, course2, course3, syllabus1, labmanual1, questionbank1, unit1_file1, unit2_file1, unit3_file1, unit4_file1, unit5_file1 FROM faculty_page WHERE id = ?";
$stmt = $connection->prepare($query);
$stmt->bind_param("i", $faculty_id); // Binding the faculty ID to query
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $name = $row['name'];
    $qualification = $row['qualification'];
    $department = $row['department'];
    $course1 = $row['course1'];
    $course2 = $row['course2'];
    $course3 = $row['course3'];
} else {
    echo "No data found.";
}
$stmt->close();
$connection->close();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Faculty Dashboard</title>
    <link href="styles.css" rel="stylesheet">
    <style type="text/css">
         * {
    padding: 0;
    margin: 0;
    box-sizing: border-box;
}

body {
    font-family: Arial, sans-serif;
    background-color: #f0f0f5;
    color: #333;
    margin: 0;
    padding: 0;linear-gradient(rgba(0, 0, 0, 0.55), rgba(0, 0, 0, 0.55)), url(background.jpg);
    background-size: cover; /* Ensure the background image covers the entire screen */
    background-position: center center; /* Center the background image */
    background-attachment: fixed; /* Keep the background fixed while scrolling */
    min-height: 100vh; /* Ensure the body covers the full viewport height */
    padding-top: 20px;
}

.container {
    width: 80%;
    margin: auto;
    padding-top: 50px;
    background-color: rgba(255, 255, 255, 0.8); /* Slightly transparent background */
    backdrop-filter: blur(5px); /* Apply a blur effect to the background */
    border-radius: 10px;
    padding-bottom: 40px; /* Add some padding at the bottom */
}

h2, h3, p {
    color: white; /* Ensure text is readable on top of the background */
    text-align: center;
}

/* Tabs */
.tab-container {
    display: inline-grid;
    justify-content: center;
    margin-top: 10px;
    padding-left: 690px;
    margin-bottom: 10px;
}

.tab-button {
    background-color: #007bff;
    color: white;
    border: none;
    padding: 10px 20px;
    cursor: pointer;
    font-size: 16px;
    margin: 0 5px;
    transition: background-color 0.3s ease;
}

.tab-button:hover {
    background-color: #0056b3;
}

.tab-button:focus {
    outline: none;
    background-color: #0056b3;
}

/* Responsive Design */
@media (max-width: 768px) {
    body {
        padding: 20px; /* Reduce padding on smaller screens */
    }

    .container {
        width: 100%;
         /* Adjust padding for smaller screens */
    }

    .tab-container {
        padding-left: 0;
        text-align: center;
        padding-left:  73px; /* Center the tabs on smaller screens */
    }

    .tab-button {
        width: 100%;
        margin-bottom: 10px;
         /* Stack the buttons vertically */
    }

    h2 {
        font-size: 1.5em;
        color: white; /* Adjust heading size */
    }

    h3 {
        font-size: 1.2em;
        color: white; /* Adjust subheading size */
    }

    p {
        font-size: 1em;
        color: white;
        + /* Adjust paragraph size */
    }

    /* Optional: Adjust content area styling on mobile */
    .tab-content {
        margin-top: 20px;
        padding: 15px; /* Reduce padding for mobile */
    }
}

@media (max-width: 480px) {
    h2 {
        font-size: 1.2em;
        column-gap: 10px; /* Adjust heading size for very small screens */
    }

    p {
        font-size: 0.9em;
        grid-column-gap: 10px; /* Adjust paragraph size for very small screens */
    }
}

    </style>
</head>
<body>
    
        <h2>Details about <?php echo htmlspecialchars($facultyData['name']); ?></h2>
        <p><strong>Name:</strong> <?php echo htmlspecialchars($name); ?></p>
        <p><strong>Qualification:</strong> <?php echo htmlspecialchars($qualification); ?></p>
        <p><strong>Department:</strong> <?php echo htmlspecialchars($department); ?></p>

        <br>
        <h3>Courses Handling</h3>
        
        <!-- Tabs -->
        <div class="tab-container">
            <button class="tab-button" onclick="loadContent('course1.php', 'Dashboard')"><?php echo htmlspecialchars($facultyData['course1']); ?></button><br>
            <button class="tab-button" onclick="loadContent('course2.php', 'Courses')"><?php echo htmlspecialchars($facultyData['course2']); ?></button><br>
            <button class="tab-button" onclick="loadContent('course3.php', 'Resources')"><?php echo htmlspecialchars($facultyData['course3']); ?></button>
        </div>
        <br>
        <br>

        <!-- Content area where tab content will load -->
        <div id="tab-content" class="">
            <p>Select a tab to view its content.</p>
        </div>
    

    <!-- JavaScript for loading tab content -->
    <script>
       function loadContent(page, title) {
    // Show loading message in tab-content
    document.getElementById('tab-content').innerHTML = `<p>Loading ${title}...</p> , <p>Loading ${title}...</p>`;

    fetch(page, {
        method: 'GET',
        credentials: 'include' // Ensures cookies (and session) are sent with the request
    })
        .then(response => {
            if (!response.ok) {
                throw new Error(`Error loading ${title}: ${response.statusText}`);
            }
            return response.text();
        })
        .then(data => {
            // Log the fetched content to verify output
            console.log("Fetched content:", data);

            // Insert HTML from the PHP page into the tab-content div
            document.getElementById('tab-content').innerHTML = data;
        })
        .catch(error => {
            console.error("Fetch error:", error);
            document.getElementById('tab-content').innerHTML = `<p>Error loading ${title} content.</p>`;
        });
}


    </script>
</body>
</html>
