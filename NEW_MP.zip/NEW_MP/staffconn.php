<?php

$faculty_log = $_REQUEST['faculty_log'];
$faculty_pass = $_REQUEST['faculty_pass'];

// Create connection
$connection = mysqli_connect("localhost", "root", "", "pg_pro");

// Check connection
if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}

// Query to check the faculty_log and password
$query = "SELECT faculty_log, faculty_pass FROM faculty_page";
$result = mysqli_query($connection, $query) or die("Query failed: " . mysqli_error($connection));

$validLogin = false; // Flag to track successful login

while ($row = mysqli_fetch_assoc($result)) {
    if ($row['faculty_log'] == $faculty_log && $row['faculty_pass'] == $faculty_pass) {
        $validLogin = true;
        break;
    }
}

// Redirect based on login validation
if ($validLogin) {
    header("Location: facultypage.php");
} else {
    echo "<script>
        alert('Email or Password Invalid');
        window.open('index.html','_self');
    </script>";
}

// Close the connection
mysqli_close($connection);
?>



<?php

$faculty_log = $_REQUEST['faculty_log'];
$faculty_pass = $_REQUEST['faculty_pass'];
$connection = mysqli_connect("localhost","root","")
or die("couldn't connect to server");
$db = mysql_select_db("pg_pro",$connection)
or die("couldn't select database");
$query = "SELECT faculty_log,faculty_pass FROM adminpage";
$result = mysql_query($query) or die("query failed".mysql_error());
while ($row = mysql_fetch_array($result)) {
	if($row['faculty_log'] == $faculty_log && $row['faculty_pass'] == $faculty_pass)
	{
		header("location:facultypage.php");
	} else {

		echo "<script> 
			alert('Email or Password Invaild');
			window.open('index.html','_self');
			</script>";
	}
	
}
mysql_close($connection);
?>