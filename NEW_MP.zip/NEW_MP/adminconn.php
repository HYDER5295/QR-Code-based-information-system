<?php

$username = $_REQUEST['adminusername'];
$password = $_REQUEST['adminpassword'];

// Create connection
$connection = mysqli_connect("localhost", "root", "", "new_pro");

// Check connection
if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}

// Query to check the username and password
$query = "SELECT username, password FROM admin_page";
$result = mysqli_query($connection, $query) or die("Query failed: " . mysqli_error($connection));

$validLogin = false; // Flag to track successful login

while ($row = mysqli_fetch_assoc($result)) {
    if ($row['username'] == $username && $row['password'] == $password) {
        $validLogin = true;
        break;
    }
}

// Redirect based on login validation
if ($validLogin) {
    header("Location: admin_page/adminpage.php");
} else {
    echo "<script>
        alert('Email or Password Invalid');
        window.open('index.html','_self');
    </script>";
}

// Close the connection
mysqli_close($connection);
?>