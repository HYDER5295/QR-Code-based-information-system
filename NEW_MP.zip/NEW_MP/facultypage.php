<?php
session_start();
if (!isset($_SESSION['facultyData'])) {
    header("Location: passcode.php"); // Redirect to login if not logged in
    exit();
}

$facultyData = $_SESSION['facultyData'];

$connection = mysqli_connect("localhost", "root", "", "new_pro");

if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}

$edit = isset($_GET['edit']) ? $_GET['edit'] : '';

// Fetch existing data if in edit mode
if ($edit) {
    $stmt = $connection->prepare("SELECT * FROM faculty_page WHERE id = ?");
    $stmt->bind_param("i", $edit);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        $uid = $row['id'];
        $name = $row['name'];
        $qualification = $row['qualification'];
        $department = $row['department'];
        $faculty_log = $row['faculty_log'];
        $faculty_pass = $row['faculty_pass'];
        $course1 = $row['course1'];
        $course2 = $row['course2'];
        $course3 = $row['course3'];
        $passcode = $row['passcode'];

        // Existing file paths
        $syllabus1_path = $row['syllabus1'];
        $labmanual1_path = $row['labmanual1'];
        $questionbank1_path = $row['questionbank1'];
        $unit1_file1_path = $row['unit1_file1'];
        $unit2_file1_path = $row['unit2_file1'];
        $unit3_file1_path = $row['unit3_file1'];
        $unit4_file1_path = $row['unit4_file1'];
        $unit5_file1_path = $row['unit5_file1'];

        $syllabus2_path = $row['syllabus2'];
        $labmanual2_path = $row['labmanual2'];
        $questionbank2_path = $row['questionbank2'];
        $unit1_file2_path = $row['unit1_file2'];
        $unit2_file2_path = $row['unit2_file2'];
        $unit3_file2_path = $row['unit3_file2'];
        $unit4_file2_path = $row['unit4_file2'];
        $unit5_file2_path = $row['unit5_file2'];

        $syllabus3_path = $row['syllabus3'];
        $labmanual3_path = $row['labmanual3'];
        $questionbank3_path = $row['questionbank3'];
        $unit1_file3_path = $row['unit1_file3'];
        $unit2_file3_path = $row['unit2_file3'];
        $unit3_file3_path = $row['unit3_file3'];
        $unit4_file3_path = $row['unit4_file3'];
        $unit5_file3_path = $row['unit5_file3'];
    }
    $stmt->close();
}

// Function to handle file upload while preserving existing file if no new upload is provided
function handleFileUpload($file, $existingFilePath) {
    $upload_dir = 'uploads/'; // Define upload directory
    $allowed_types = array('pdf', 'doc', 'docx', 'jpg', 'png'); // Allowed file types

    if (!empty($_FILES[$file]['name'])) {
        $file_tmp = $_FILES[$file]['tmp_name'];
        $file_name = $_FILES[$file]['name'];
        $file_type = pathinfo($file_name, PATHINFO_EXTENSION);

        if (in_array($file_type, $allowed_types)) {
            $destination = $upload_dir . basename($file_name);
            if (move_uploaded_file($file_tmp, $destination)) {
                return $destination;
            } else {
                echo "Error uploading $file_name.";
            }
        }
    }
    return $existingFilePath; // Return existing path if no new file uploaded
}

// Handle form submission and update
if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    $qualification = $_POST['qualification'];
    $department = $_POST['department'];
    $faculty_log = $_POST['faculty_log'];
    $faculty_pass = $_POST['faculty_pass'];
    $course1 = $_POST['course1'];
    $course2 = $_POST['course2'];
    $course3 = $_POST['course3'];
    $passcode = $_POST['passcode'];

    // Update file paths by either uploading new files or retaining existing ones
    $syllabus1_path = handleFileUpload('syllabus1', $syllabus1_path);
    $labmanual1_path = handleFileUpload('labmanual1', $labmanual1_path);
    $questionbank1_path = handleFileUpload('questionbank1', $questionbank1_path);
    $unit1_file1_path = handleFileUpload('unit1_file1', $unit1_file1_path);
    $unit2_file1_path = handleFileUpload('unit2_file1', $unit2_file1_path);
    $unit3_file1_path = handleFileUpload('unit3_file1', $unit3_file1_path);
    $unit4_file1_path = handleFileUpload('unit4_file1', $unit4_file1_path);
    $unit5_file1_path = handleFileUpload('unit5_file1', $unit5_file1_path);

    $syllabus2_path = handleFileUpload('syllabus2', $syllabus2_path);
    $labmanual2_path = handleFileUpload('labmanual2', $labmanual2_path);
    $questionbank2_path = handleFileUpload('questionbank2', $questionbank2_path);
    $unit1_file2_path = handleFileUpload('unit1_file2', $unit1_file2_path);
    $unit2_file2_path = handleFileUpload('unit2_file2', $unit2_file2_path);
    $unit3_file2_path = handleFileUpload('unit3_file2', $unit3_file2_path);
    $unit4_file2_path = handleFileUpload('unit4_file2', $unit4_file2_path);
    $unit5_file2_path = handleFileUpload('unit5_file2', $unit5_file2_path);

    $syllabus3_path = handleFileUpload('syllabus3', $syllabus3_path);
    $labmanual3_path = handleFileUpload('labmanual3', $labmanual3_path);
    $questionbank3_path = handleFileUpload('questionbank3', $questionbank3_path);
    $unit1_file3_path = handleFileUpload('unit1_file3', $unit1_file3_path);
    $unit2_file3_path = handleFileUpload('unit2_file3', $unit2_file3_path);
    $unit3_file3_path = handleFileUpload('unit3_file3', $unit3_file3_path);
    $unit4_file3_path = handleFileUpload('unit4_file3', $unit4_file3_path);
    $unit5_file3_path = handleFileUpload('unit5_file3', $unit5_file3_path);

    // Update the faculty data along with all file paths
    $stmt = $connection->prepare("UPDATE faculty_page SET name = ?, qualification = ?, department = ?, faculty_log = ?, faculty_pass = ?, course1 = ?, course2 = ?, course3 = ?, passcode = ?, syllabus1 = ?, labmanual1 = ?, questionbank1 = ?, unit1_file1 = ?, unit2_file1 = ?, unit3_file1 = ?, unit4_file1 = ?, unit5_file1 = ?, syllabus2 = ?, labmanual2 = ?, questionbank2 = ?, unit1_file2 = ?, unit2_file2 = ?, unit3_file2 = ?, unit4_file2 = ?, unit5_file2 = ?, syllabus3 = ?, labmanual3 = ?, questionbank3 = ?, unit1_file3 = ?, unit2_file3 = ?, unit3_file3 = ?, unit4_file3 = ?, unit5_file3 = ? WHERE id = ?");
    $stmt->bind_param("sssssssssssssssssssssssssssssssssi", $name, $qualification, $department, $faculty_log, $faculty_pass, $course1, $course2, $course3, $passcode, $syllabus1_path, $labmanual1_path, $questionbank1_path, $unit1_file1_path, $unit2_file1_path, $unit3_file1_path, $unit4_file1_path, $unit5_file1_path, $syllabus2_path, $labmanual2_path, $questionbank2_path, $unit1_file2_path, $unit2_file2_path, $unit3_file2_path, $unit4_file2_path, $unit5_file2_path, $syllabus3_path, $labmanual3_path, $questionbank3_path, $unit1_file3_path, $unit2_file3_path, $unit3_file3_path, $unit4_file3_path, $unit5_file3_path, $edit);

    if ($stmt->execute()) {
        echo "<script>
        alert('Details and Materials of your Courses are uploaded successfully');
        window.open('facultypage.php', '_self');
        </script>";
    } else {
        echo "Error: " . $stmt->error;
    }
    $stmt->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Faculty Details</title>
    <link href="styles.css" rel="stylesheet">
     <script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js"></script>
    
    <style>
        * {
            margin: 0;
            padding: 0;
            font-family: sans-serif;
            box-sizing: border-box;
        }

        .banner {
            width: 100%;
            height: 100%;
            background-image: linear-gradient(rgba(0, 0, 0, 0.75), rgba(0, 0, 0, 0.75)), url(background.jpg);
            background-size: cover;
            background-position: center;
            background-attachment: fixed;
        }

        .navbar {
            width: 90%;
            margin: auto;
            padding: 20px 0;
            display: flex;
            align-items: center;
            justify-content: space-between;
            flex-wrap: wrap;
        }

        .logo {
            width: 100px;
            height: auto;
        }

        .navbar ul {
            list-style: none;
            display: flex;
            flex-wrap: wrap;
            gap: 15px;
        }

        .navbar ul li {
            display: inline-block;
            position: relative;
        }

        .navbar ul li a {
            text-decoration: none;
            color: #fff;
            text-transform: uppercase;
            padding: 15px 20px;
            display: block;
        }

        .container {
            padding: 20px;
             position: relative;
        }



.view {
    position: absolute;
    top: 10px;
    right: 10px;
    margin-top: 5px;
    padding: 8px 15px;
    font-size: 14px;
}

.view:hover {
    color: white;
}


        h2, h3 {
            color: #fff;
        }

        .form-group {
            margin-bottom: 15px;
        }

        .form-control {
            width: 100%;
            padding: 8px;
            margin-top: 5px;
        }

        .courses-section {
            padding: 10px;
            border: 1px solid #333;
            margin-bottom: 20px;
        }

        .center-button {
            display: flex;
            justify-content: center;
            margin-top: 20px;
        }

        .btn {
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
        }

        .btn:hover {
            background-color: #45a049;
        }

        #qrcode {
            margin-top: 20px;
            display: flex;
            justify-content: center;
        }

        .download-btn {
            padding: 10px 20px;
            background-color: #008CBA;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            margin-top: 10px;
        }

        .download-btn:hover {
            background-color: #007bb5;
        }

        /* Responsive Styling */
        @media (max-width: 768px) {
            .navbar {
                flex-direction: column;
            }

            .navbar ul {
                flex-direction: column;
                align-items: center;
            }

            .courses-row {
                flex-direction: column;
            }

            .form-group label,
            .form-group input,
            .form-group button {
                width: 100%;
            }

            .btn,
            .download-btn {
                width: 100%;
                font-size: 18px;
            }
        }

        @media (max-width: 576px) {
            h2, h3 {
                font-size: 1.5em;
            }

            .form-control {
                font-size: 14px;
            }

            .btn,
            .download-btn {
                font-size: 16px;
            }
        }
    </style>

    <script>
        function validateForm() {
            const password = document.getElementById("faculty_pass").value;
            const passcode = document.getElementById("passcode").value;
            const passwordPattern = /^(?=.*[A-Z]).{8,}$/;
            const passcodePattern = /^\d{6}$/;


            if (!passwordPattern.test(password)) {
                alert("Faculty login Password must be at least 8 characters long and include an '@' symbol, and contains atleast one capital letter");
                return false;
            }
            if (!passcodePattern.test(passcode)) {
                alert("Passcode should be 6 digits");
                return false;
            }
            return true;
        }
    </script>
    
</head>
<body>

    <div class="banner">
    <div class="navbar">
    <img src="scanme.jpg" class="logo">
    <ul>
        <li><a href="index.html">Home</a></li>
        <li><a href="#">About us</a></li>
        <li><a href="#">Contact us</a></li>
        <li><a href="logout.php">Logout</a></li>
        
    </ul>
</div>





    <div class="container">
        
   
        <h2>Faculty Details</h2>
        <p><strong>Name:</strong> <?php echo htmlspecialchars($facultyData['name']); ?></p>
        <p><strong>Department:</strong> <?php echo htmlspecialchars($facultyData['department']); ?></p>

        <h3>Edit Faculty Data</h3>
        <form action="facultypage.php?edit=<?php echo $facultyData['id']; ?>" method="post" enctype="multipart/form-data"  onsubmit="return validateForm()">
            <div class="form-group mb-3">
                <label for="name">Name</label>
                <input type="text" name="name" id="name" class="form-control" placeholder="Enter Name" value="<?php echo htmlspecialchars($facultyData['name']); ?>" required>
            </div>
            <div class="form-group mb-3">
                <label for="qualification">Qualification</label>
                <input type="text" name="qualification" id="qualification" class="form-control" placeholder="Enter qualification" value="<?php echo htmlspecialchars($facultyData['qualification']); ?>" required>
            </div>
            <div class="form-group mb-3">
                <label for="Department">Department</label>
                <input type="text" name="department" id="department" class="form-control" placeholder="Enter Department" value="<?php echo htmlspecialchars($facultyData['department']); ?>" required>
            </div>
            <div class="form-group mb-3">
                <label for="faculty_log">Faculty Login ID</label>
                <input type="text" name="faculty_log" id="faculty_log" class="form-control" placeholder="Enter Faculty Login ID" value="<?php echo htmlspecialchars($facultyData['faculty_log']); ?>" required>
            </div>
            <div class="form-group mb-3">
                <label for="faculty_pass">Faculty Login Password</label>
                <input type="password" name="faculty_pass" id="faculty_pass" class="form-control" placeholder="Enter Faculty Login Password" value="<?php echo htmlspecialchars($facultyData['faculty_pass']); ?>" required>
            </div>

            <div class="courses-section">
                <h3>Courses</h3>
                <div class="courses-row">
                    <div class="form-group">
                        <label for="course1">Course 1</label>
                        <input type="text" name="course1" id="course1" class="form-control" placeholder="Enter Course 1" value="<?php echo htmlspecialchars($facultyData['course1']); ?>" required>
                       

                    
                        <br>
                        <br>
                        <br>
                        <h4>Syllabus</h4>
                        <input type="file" name="syllabus1" id="syllabus1" class="form-control">
 <?php if (!empty($syllabus1_path)): ?>
        <p>Current File: <?php echo basename($syllabus1_path); ?></p>
    <?php endif; ?>
                        <br>
                        
                        <br>
                        <h4>Lab Manual</h4>
                        <input type="file" name="labmanual1" id="labmanual1" class="form-control">
 <?php if (!empty($labmanual1_path)): ?>
        <p>Current File: <?php echo basename($labmanual1_path); ?></p>
    <?php endif; ?>
                        <br>
                        <br>
                        <h4>Question Bank</h4>
                        <input type="file" name="questionbank1" id="questionbank1" class="form-control"><br>
                        <br>
                        <h4>Unit Files</h4>
                        <br>
                        <label for="unit1_file1">Unit 1</label>
                        <input type="file" name="unit1_file1" id="unit1_file1" class="form-control"><br>
                        <br>
                        <label for="unit2_file1">Unit 2</label>
                        <input type="file" name="unit2_file1" id="unit2_file1" class="form-control"><br>
                        <br>
                        <label for="unit3_file1">Unit 3</label>
                        <input type="file" name="unit3_file1" id="unit3_file1" class="form-control"><br>
                        <br>
                        <label for="unit4_file1">Unit 4</label>
                        <input type="file" name="unit4_file1" id="unit4_file1" class="form-control"><br>
                        <br>
                        <label for="unit5_file1">Unit 5</label>
                        <input type="file" name="unit5_file1" id="unit5_file1" class="form-control"><br>
                    </div>

                    <div class="form-group">
                        <label for="course2">Course 2</label>
                        <input type="text" name="course2" id="course2" class="form-control" placeholder="Enter Course 2" value="<?php echo htmlspecialchars($facultyData['course2']); ?>" required>
                       

                        <br>
                        <br>
                        <br>
                        <h4>Syllabus</h4>
                        <input type="file" name="syllabus2" id="syllabus2" class="form-control"><br>
                        <br>
                        <h4>Lab Manual</h4>
                        <input type="file" name="labmanual2" id="labmanual2" class="form-control"><br>
                        <br>
                        <h4>Question Bank</h4>
                        <input type="file" name="questionbank2" id="questionbank2" class="form-control"><br>
                        <br>
                        <h4>Unit Files</h4>
                        <br>
                        <label for="unit1_file2">Unit 1</label>
                        <input type="file" name="unit1_file2" id="unit1_file2" class="form-control"><br>
                        <br>
                        <label for="unit2_file2">Unit 2</label>
                        <input type="file" name="unit2_file2" id="unit2_file2" class="form-control"><br>
                        <br>
                        <label for="unit3_file2">Unit 3</label>
                        <input type="file" name="unit3_file2" id="unit3_file2" class="form-control"><br>
                        <br>
                        <label for="unit4_file2">Unit 4</label>
                        <input type="file" name="unit4_file2" id="unit4_file2" class="form-control"><br>
                        <br>
                        <label for="unit5_file2">Unit 5</label>
                        <input type="file" name="unit5_file2" id="unit5_file2" class="form-control"><br>
                    </div>

                    <div class="form-group">
                        <label for="course3">Course 3</label>
                        <input type="text" name="course3" id="course3" class="form-control" placeholder="Enter Course 3" value="<?php echo htmlspecialchars($facultyData['course3']); ?>" required>
                        

                        <br>
                        <br>
                        <br>
                        <h4>Syllabus</h4>
                        <input type="file" name="syllabus3" id="syllabus3" class="form-control"><br>
                        <br>
                        <h4>Lab Manual</h4>
                        <input type="file" name="labmanual3" id="labmanual3" class="form-control"><br>
                        <br>
                        <h4>Question Bank</h4>
                        <input type="file" name="questionbank3" id="questionbank3" class="form-control"><br>
                        <br>
                        <h4>Unit Files</h4>
                        <br>
                        <label for="unit1_file3">Unit 1</label>
                        <input type="file" name="unit1_file3" id="unit1_file3" class="form-control"><br>
                        <br>
                        <label for="unit2_file3">Unit 2</label>
                        <input type="file" name="unit2_file3" id="unit2_file3" class="form-control"><br>
                        <br>
                        <label for="unit3_file3">Unit 3</label>
                        <input type="file" name="unit3_file3" id="unit3_file3" class="form-control"><br>
                        <br>
                        <label for="unit4_file3">Unit 4</label>
                        <input type="file" name="unit4_file3" id="unit4_file3" class="form-control"><br>
                        <br>
                        <label for="unit5_file3">Unit 5</label>
                        <input type="file" name="unit5_file3" id="unit5_file3" class="form-control"><br>
                    </div>
                </div>
            </div>

            <br>

             <div class="form-group mb-3">
                <label for="Passcode">Passcode</label>
                <input type="text" name="passcode" id="passcode" class="form-control" placeholder="Enter Department" value="<?php echo htmlspecialchars($facultyData['passcode']); ?>" required>
            </div>


            <button type="submit" name="submit" class="btn btn-primary">Update Data</button>
        </form>

        <!-- Center the Generate button -->
        <div class="center-button">
            <button class="btn" onclick="generateQRCode()">Generate QR Code</button>
        </div>

        <!-- QR Code container -->
        <div id="qrcode"></div><br>
        <div id="passcode-display" style="text-align: center; font-weight: bold;"></div>

        <!-- Download button (hidden until QR code is generated) -->
        <div class="center-button">
            <a id="download-link" style="display:none;" download="qrcode.png">
                <button class="download-btn">Download QR Code</button>
            </a>
        </div>
        <div class="view">
         <button class="btn" onclick="window.location.href='stu1.php'">View My Updated Files</button>
     </div>
    </div>

<script>
// Pass faculty ID from PHP to JavaScript
const facultyId = <?php echo $facultyData['id']; ?>;

function generateQRCode() {
    const passcode = document.getElementById("passcode").value;
    const qrcodeContainer = document.getElementById("qrcode");
    const passcodeDisplay = document.getElementById("passcode-display");
    const downloadLink = document.getElementById("download-link");

    qrcodeContainer.innerHTML = ""; // Clear any previous QR code
    passcodeDisplay.innerHTML = ""; // Clear any previous passcode display

    // Construct the URL to passcode1.php with the faculty ID
    const redirectUrl = window.location.origin + '/NEW_MP/passcode.php?id=' + facultyId;

    // Create the QR code
    const qrCode = new QRCode(qrcodeContainer, {
        text: redirectUrl,
        width: 128,
        height: 128,
        colorDark: "#000000",
        colorLight: "#ffffff",
        correctLevel: QRCode.CorrectLevel.H
    });

    // Display the passcode below the QR code in bold
    passcodeDisplay.innerHTML = "Passcode: " + passcode;

    // Show the download button after generating the QR code
    downloadLink.style.display = "block";
    downloadLink.href = qrcodeContainer.querySelector("canvas").toDataURL("image/png");
}

</script>

</body>
</html>

    </div>
    </div>
</body>
</html>