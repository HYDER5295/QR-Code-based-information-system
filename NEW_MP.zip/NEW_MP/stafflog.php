<?php
$connection = mysqli_connect("localhost", "root", "", "new_pro");

if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}

// Initialize variables
$loggedIn = false;
$facultyData = null;

// Handle login
if (isset($_POST['login'])) {
    $faculty_log = $_POST['faculty_log'];
    $faculty_pass = $_POST['faculty_pass'];

    // Verify credentials
    $stmt = $connection->prepare("SELECT * FROM faculty_page WHERE faculty_log = ? AND faculty_pass = ?");
    $stmt->bind_param("ss", $faculty_log, $faculty_pass);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        $loggedIn = true;
        $facultyData = $row; // Store faculty data for display
        session_start();
        $_SESSION['facultyData'] = $facultyData; // Store faculty data in session
        header("Location: facultypage.php");
        exit();
    } else {
        echo "<script>alert('Invalid login credentials!');</script>";
    }
    $stmt->close();
}

$connection->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Faculty Login</title>
    <link href="styles.css" rel="stylesheet">
    <script>
        function validateForm() {
            const password = document.getElementById("faculty_pass").value;
            const passwordPattern = /^(?=.*[@])(?=.*[A-Z]).{8,}$/;

            if (!passwordPattern.test(password)) {
                alert("Faculty login Password must be at least 8 characters long and include an '@' symbol, and contains atleast one capital letter");
                return false;
            }
            return true;
        }
    </script>
</head>
<body>
    <div class="container">
        <h1>Faculty Login</h1>
        <form action="" method="post" onsubmit="return validateForm()">
            <div class="form-group mb-3">
                <label for="faculty_log">Faculty Login ID</label>
                <input type="text" name="faculty_log" id="faculty_log" class="form-control" placeholder="Enter Faculty Login ID" required>
            </div>
            <div class="form-group mb-3">
                <label for="faculty_pass">Faculty Login Password</label>
                <input type="password" name="faculty_pass" id="faculty_pass" class="form-control" placeholder="Enter Faculty Login Password" required>
            </div>
            <input type="submit" class="btn btn-primary" name="login" value="Login">
        </form>
    </div>
</body>
</html>