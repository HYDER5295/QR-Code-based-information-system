function generateQRCode() {
    document.getElementById("qrcode").innerHTML = "";
    document.getElementById("download-link").style.display = "none";
    document.getElementById("message").innerText = "Generating QR Code...";

    // Use your local IP address with the specific path
    var localURL = "http://192.168.131.189/MP/course1.php"; // Update to your local IP and path

    var qrcode = new QRCode(document.getElementById("qrcode"), {
        text: localURL,
        width: 128,
        height: 128,
        errorCorrectionLevel: 'H',
    });

    setTimeout(function () {
        var qrCanvas = document.querySelector("#qrcode canvas");
        if (qrCanvas) {
            var qrDataURL = qrCanvas.toDataURL("image/png");
            var downloadLink = document.getElementById("download-link");
            downloadLink.href = qrDataURL;
            downloadLink.style.display = "inline-block";
            document.getElementById("message").innerText = "QR Code generated! Scan it now.";
        } else {
            document.getElementById("message").innerText = "Error generating QR Code.";
        }
    }, 500);
}
