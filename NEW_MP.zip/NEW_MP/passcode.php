<?php
session_start();
$connection = mysqli_connect("localhost", "root", "", "new_pro");

if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}

// Initialize variables
if (isset($_GET['id'])) {
    $faculty_id = $_GET['id']; // Get the faculty ID from the URL
} else {
    echo "No faculty ID found.";
    exit();
}

// Handle login
if (isset($_POST['login'])) {
    $passcode = $_POST['passcode']; // Get the passcode from the form

    // Verify credentials and retrieve faculty data based on the faculty_id
    $stmt = $connection->prepare("SELECT * FROM faculty_page WHERE id = ? AND passcode = ?");
    $stmt->bind_param("is", $faculty_id, $passcode); // Ensure the correct types are passed (i for int, s for string)
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        $loggedIn = true;
        $facultyData = $row; // Store faculty data for display
        $_SESSION['facultyData'] = $facultyData; // Store faculty data in session
        header("Location: stu1.php");
        exit();
    } else {
        echo "<script>alert('Invalid passcode or faculty ID!');</script>";
    }
    $stmt->close();
}

$connection->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Faculty Login</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f5;
            background-image: linear-gradient(rgba(0,0,0,0.55),rgba(0,0,0,0.55)), url(background.jpg);
            color: #333;
        }

        .container {
            max-width: 400px;
            margin: 50px auto;
            background-color: #f0f0f5;
            padding: 30px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        .form-control {
            width: 100%;
        }

        @media (max-width: 576px) {

            body{
                justify-content: center;
                padding-top: 200px;

            }
            .container {
                padding: 20px;
                width: 90%;
                margin: 10px auto;
            }

            h1 {
                font-size: 1.5rem;
            }
        }
    </style>
</head>
<body>
    <div class="container">
        <h1 class="text-center">Enter the Passcode</h1>
        <form action="" method="post">
            <div class="form-group mb-3">
                <label for="passcode">Passcode</label>
                <input type="password" name="passcode" id="passcode" class="form-control" placeholder="Enter Passcode" required>
            </div>
            <input type="submit" class="btn btn-primary w-100" name="login" value="Login">
        </form>
    </div>

    <!-- Bootstrap JS (Optional for mobile-specific behavior) -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>





