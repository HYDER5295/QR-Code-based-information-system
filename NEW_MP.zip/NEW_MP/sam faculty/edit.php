<?php
$connection = mysqli_connect("localhost", "root", "", "faculty_list");

if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}

$edit = isset($_GET['edit']) ? $_GET['edit'] : '';

if ($edit) {
    // Fetch the existing student data
    $stmt = $connection->prepare("SELECT * FROM student WHERE id = ?");
    $stmt->bind_param("i", $edit);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        $uid = $row['id'];
        $name = $row['name'];
        $course = $row['course'];
        $faculty_log = $row['faculty_log'];
        $faculty_pass = $row['faculty_pass'];
    }
    $stmt->close();
}

if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    $course = $_POST['course'];
    $faculty_log = $_POST['faculty_log'];
    $faculty_pass = $_POST['faculty_pass'];

    // Update the student data
    $stmt = $connection->prepare("UPDATE student SET name = ?, course = ?, faculty_log = ?, faculty_pass = ? WHERE id = ?");
    $stmt->bind_param("ssssi", $name, $course, $faculty_log, $faculty_pass, $edit);

    if ($stmt->execute()) {
        echo '<script>location.replace("index.php")</script>';
    } else {
        echo "Error: " . $stmt->error;
    }
    $stmt->close();
}

$connection->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student CRUD Application</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-md-9">
                <div class="card">
                    <div class="card-header">
                        <h1>Student CRUD Application</h1>
                    </div>
                    <div class="card-body">
                        <form action="edit.php?edit=<?php echo $edit; ?>" method="post">
                            <div class="form-group">
                                <label>Name</label>
                                <input type="text" name="name" class="form-control" placeholder="Enter Name" value="<?php echo htmlspecialchars($name); ?>"> 
                            </div>
                            <div class="form-group">
                                <label>Course</label>
                                <input type="text" name="course" class="form-control" placeholder="Enter Course" value="<?php echo htmlspecialchars($course); ?>"> 
                            </div>
                            <div class="form-group">
                                <label>Faculty Login ID</label>
                                <input type="text" name="faculty_log" class="form-control" placeholder="Enter Faculty Login ID" value="<?php echo htmlspecialchars($faculty_log); ?>"> 
                            </div>
                            <div class="form-group">
                                <label>Faculty Login Password</label>
                                <input type="password" name="faculty_pass" class="form-control" placeholder="Enter Faculty Login Password" value="<?php echo htmlspecialchars($faculty_pass); ?>"> 
                            </div>
                            <br/>
                            <input type="submit" class="btn btn-primary" name="submit" value="Edit">
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>
