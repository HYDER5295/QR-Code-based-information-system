-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 09, 2024 at 03:35 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `new_pro`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_page`
--

CREATE TABLE `admin_page` (
  `username` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `admin_page`
--

INSERT INTO `admin_page` (`username`, `password`) VALUES
('admin@123', '123');

-- --------------------------------------------------------

--
-- Table structure for table `faculty_page`
--

CREATE TABLE `faculty_page` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `qualification` varchar(100) NOT NULL,
  `faculty_log` varchar(100) NOT NULL,
  `faculty_pass` varchar(100) NOT NULL,
  `department` varchar(100) NOT NULL,
  `course1` varchar(100) NOT NULL,
  `course2` varchar(100) NOT NULL,
  `course3` varchar(100) NOT NULL,
  `syllabus1` varchar(100) DEFAULT NULL,
  `syllabus2` varchar(100) DEFAULT NULL,
  `syllabus3` varchar(100) DEFAULT NULL,
  `labmanual1` varchar(100) NOT NULL,
  `labmanual2` varchar(100) NOT NULL,
  `labmanual3` varchar(100) NOT NULL,
  `questionbank1` varchar(100) NOT NULL,
  `questionbank2` varchar(100) NOT NULL,
  `questionbank3` varchar(100) NOT NULL,
  `unit1_file1` varchar(100) NOT NULL,
  `unit2_file1` varchar(100) NOT NULL,
  `unit3_file1` varchar(100) NOT NULL,
  `unit4_file1` varchar(100) NOT NULL,
  `unit5_file1` varchar(100) NOT NULL,
  `unit1_file2` varchar(100) NOT NULL,
  `unit2_file2` varchar(100) NOT NULL,
  `unit3_file2` varchar(100) NOT NULL,
  `unit4_file2` varchar(100) NOT NULL,
  `unit5_file2` varchar(100) NOT NULL,
  `unit1_file3` varchar(100) NOT NULL,
  `unit2_file3` varchar(100) NOT NULL,
  `unit3_file3` varchar(100) NOT NULL,
  `unit4_file3` varchar(100) NOT NULL,
  `unit5_file3` varchar(100) NOT NULL,
  `passcode` int(6) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `faculty_page`
--

INSERT INTO `faculty_page` (`id`, `name`, `qualification`, `faculty_log`, `faculty_pass`, `department`, `course1`, `course2`, `course3`, `syllabus1`, `syllabus2`, `syllabus3`, `labmanual1`, `labmanual2`, `labmanual3`, `questionbank1`, `questionbank2`, `questionbank3`, `unit1_file1`, `unit2_file1`, `unit3_file1`, `unit4_file1`, `unit5_file1`, `unit1_file2`, `unit2_file2`, `unit3_file2`, `unit4_file2`, `unit5_file2`, `unit1_file3`, `unit2_file3`, `unit3_file3`, `unit4_file3`, `unit5_file3`, `passcode`) VALUES
(16, 'Sam_name', 'MCA, PhD', 'Sample', 'Sam@1234', 'Sam_department', 'Sample Course1', 'Sample course2', 'Sample course3', 'uploads/qrcode (10).png', NULL, NULL, '', 'uploads/qrcode (5).png', '', '', '', '', 'uploads/qrcode (11).png', '', '', '', '', '', '', '', '', 'uploads/qrcode (11).png', '', '', '', '', '', 123456);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_page`
--
ALTER TABLE `admin_page`
  ADD KEY `username` (`username`);

--
-- Indexes for table `faculty_page`
--
ALTER TABLE `faculty_page`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `faculty_page`
--
ALTER TABLE `faculty_page`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
