<?php
$connection = mysqli_connect("localhost", "root", "", "new_pro");

if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}

$edit = isset($_GET['edit']) ? $_GET['edit'] : '';

if ($edit) {
    // Fetch the existing student data
    $stmt = $connection->prepare("SELECT * FROM faculty_page WHERE id = ?");
    $stmt->bind_param("i", $edit);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($row = $result->fetch_assoc()) {
        $uid = $row['id'];
        $name = $row['name'];
        $department = $row['department'];
        $faculty_log = $row['faculty_log'];
        $faculty_pass = $row['faculty_pass'];
    }
    $stmt->close();
}

if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    $department = $_POST['department'];
    $faculty_log = $_POST['faculty_log'];
    $faculty_pass = $_POST['faculty_pass'];

    // Update the student data
    $stmt = $connection->prepare("UPDATE faculty_page SET name = ?, department = ?, faculty_log = ?, faculty_pass = ? WHERE id = ?");
    $stmt->bind_param("ssssi", $name, $department, $faculty_log, $faculty_pass, $edit);

    if ($stmt->execute()) {
        echo '<script>location.replace("adminpage.php")</script>';
    } else {
        echo "Error: " . $stmt->error;
    }
    $stmt->close();
}

$connection->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QR-Code Information Sytem</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            background-image: linear-gradient(rgba(0,0,0,0.55),rgba(0,0,0,0.55)),url(background.jpg);
            background-size: cover;
            background-position: center;
        }

        .container {
            max-width: 800px;
            margin: 50px auto;
            padding: 30px;
            border-radius: 10px;
            background: transparent;
            border: 2px solid rgba(255,255,255, 0.2);
            backdrop-filter: blur(20px);
            box-shadow: 0 0 10px rgba(0,0,0,0.2);
            color: #fff;
        }

        h1 {
            text-align: center;
            margin-bottom: 30px;
        }

        .form-group label {
            color: #fff;
            font-size: 18px;
            margin-bottom: 10px;
        }

        .form-control {
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }

        .btn-primary {
            background-color: #007bff;
            color: white;
            width: 100%;
            padding: 10px;
            border: none;
            border-radius: 5px;
            font-size: 18px;
            cursor: pointer;
            margin-top: 20px;
        }

        .btn-primary:hover {
            background-color: #0056b3;
        }
    </style>

<script>
        function validateForm() {
            const password = document.getElementById("faculty_pass").value;
            const passwordPattern = /^(?=.*[@])(?=.*[A-Z]).{8,}$/;

            if (!passwordPattern.test(password)) {
                alert("Faculty login Password must be at least 8 characters long and include an '@' symbol, and contains atleast one capital letter");
                return false;
            }
            return true;
        }
    </script>


</head>
<body>
    <div class="container">
        <h1>Edit Faculty Data</h1>
        <form action="edit.php?edit=<?php echo $edit; ?>" method="post" onsubmit="return validateForm()">
            <div class="form-group mb-3">
                <label for="name">Name</label>
                <input type="text" name="name" id="name" class="form-control" placeholder="Enter Name" value="<?php echo htmlspecialchars($name); ?>">
            </div>
            <div class="form-group mb-3">
                <label for="course">Department</label>
                <input type="text" name="department" id="department" class="form-control" placeholder="Enter Department" value="<?php echo htmlspecialchars($department); ?>">
            </div>
            <div class="form-group mb-3">
                <label for="faculty_log">Faculty Login ID</label>
                <input type="text" name="faculty_log" id="faculty_log" class="form-control" placeholder="Enter Faculty Login ID" value="<?php echo htmlspecialchars($faculty_log); ?>">
            </div>
            <div class="form-group mb-3">
                <label for="faculty_pass">Faculty Login Password</label>
                <input type="password" name="faculty_pass" id="faculty_pass" class="form-control" placeholder="Enter Faculty Login Password" value="<?php echo htmlspecialchars($faculty_pass); ?>">
            </div>
            <input type="submit" class="btn btn-primary" name="submit" value="Update">
        </form>
    </div>
</body>
</html>