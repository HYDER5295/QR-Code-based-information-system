<?php
$connection = mysqli_connect("localhost", "root", "");
$db = mysqli_select_db($connection, "new_pro");

if (isset($_POST['submit'])) {
    $name = $_POST['name'];
    $department = $_POST['department'];
    $faculty_log = $_POST['faculty_log'];
    $faculty_pass = $_POST['faculty_pass'];

    $sql = "INSERT INTO faculty_page (name, department, faculty_log, faculty_pass) VALUES ('$name', '$department', '$faculty_log', '$faculty_pass')";

    if (mysqli_query($connection, $sql)) {
        echo '<script>location.replace("adminpage.php")</script>';
    } else {
        echo "Something went wrong: " . $connection->error;
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QR-Code Information System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            background-image: linear-gradient(rgba(0,0,0,0.55), rgba(0,0,0,0.55)), url(background.jpg);
            background-size: cover;
            background-position: center;
        }

        .container {
            max-width: 900px; /* Wider container */
            margin: 50px auto;
            padding: 40px;
            border-radius: 15px;
            background: rgba(255,255,255, 0.1); /* Light transparent background */
            border: 2px solid rgba(255, 255, 255, 0.2);
            backdrop-filter: blur(20px);
            box-shadow: 0 0 20px rgba(0,0,0,0.2);
            color: #fff;
        }

        h1 {
            text-align: center;
            margin-bottom: 30px;
        }

         .form-group label {
            color: #fff;
            font-size: 18px;
            margin-bottom: 10px;
        }

        .form-control {
            padding: 10px;
            border-radius: 5px;
            border: 1px solid #ccc;
        }

        .btn-primary {
            background-color: #007bff;
            color: white;
            width: 100%;
            padding: 10px;
            border: none;
            border-radius: 5px;
            font-size: 18px;
            cursor: pointer;
            margin-top: 20px;
        }

        .btn-primary:hover {
            background-color: #0056b3;
        }


    </style>
    <script>
        function validateForm() {
            const password = document.getElementById("faculty_pass").value;
            const passwordPattern = /^(?=.*[@])(?=.*[A-Z]).{8,}$/;

            if (!passwordPattern.test(password)) {
                alert("Faculty login Password must be at least 8 characters long and include an '@' symbol, and contains atleast one capital letter");
                return false;
            }
            return true;
        }
    </script>
</head>
<body>

    <div class="container">
        <h1>Add New Staff</h1>
        <div class="row">
            
            <form action="add.php" method="post" onsubmit="return validateForm()">
                <div class="form-group mb-3">
                    <label>Name</label>
                    <input type="text" name="name" class="form-control" placeholder="Enter Name" required>
                </div>

                <div class="form-group mb-3">
                    <label>Department</label>
                    <input type="text" name="department" class="form-control" placeholder="Enter Department" required>
                </div>

                <div class="form-group mb-3">
                    <label>Faculty Login ID</label>
                    <input type="text" name="faculty_log" class="form-control" placeholder="Enter Faculty Login ID" required>
                </div>

                <div class="form-group mb-3">
                    <label>Faculty Login Password</label>
                    <input type="password" name="faculty_pass" id="faculty_pass" class="form-control" placeholder="Enter Faculty Login Password" required>
                </div>

                <input type="submit" class="btn btn-primary" name="submit" value="Add New Staff">
            </form>
                    
        </div>
    </div>

</body>
</html>