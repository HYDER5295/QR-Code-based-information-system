<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QR-Code Information System</title>
    <link rel="stylesheet" type="text/css" href="adminstyle.css">
    <style>
        /* Moved CSS directly into the file for demonstration */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            background-image: linear-gradient(rgba(0,0,0,0.55),rgba(0,0,0,0.55)),url(background.jpg);
            background-size: cover;
            background-position: center;
        }

        .container {
            max-width: 900px;
            margin: 50px auto;
            padding: 30px;
            border-radius: 10px;
            background: transparent;
            border: 2px solid rgba(255,255,255, 0.2);
            backdrop-filter: blur(20px);
            box-shadow: 0 0 10px rgba(0,0,0,0.2);
            color: #fff;
            position: relative;
            padding-bottom: 100px;
        }

        h1 {
            text-align: center;
            margin-bottom: 30px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 30px;
        }

        table th, table td {
            padding: 15px;
            border-bottom: 1px solid #ddd;
            font-size: 18px;
            color: #fff;
        }

        .buttons {
            display: flex;
            padding-bottom: 30px;
            border-bottom: 1px solid #ddd;
            gap: 20px;
            padding-top: 20px;
            text-align: center;
        }

        .btn {
            padding: 7px 15px;
            border: none;
            border-radius: 3px;
            cursor: pointer;
        }

        .btn-success {
            background-color: #28a745;
            color: white;
        }

        .btn-success:hover {
            background-color: #178201;
        }

        .btn-danger {
            background-color: #dc3545;
            color: white;
        }

        .btn-danger:hover {
            background-color: #800603;
        }

        .btn a {
            color: white;
            text-decoration: none;
        }

        .add-btn {
            background-color: #007bff;
            color: white;
            width: 100%;
            height: 50px;
            border: none;
            border-radius: 10px;
            font-size: 20px;
            font-weight: bold;
            cursor: pointer;
            display: flex;
            justify-content: center;
            align-items: center;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.2);
            margin-top: 20px;
        }

        /* Ensure entire button is clickable */
        .add-btn a {
            display: block;
            width: 100%;
            height: 100%;
            text-align: center;
            color: white;
            text-decoration: none;
            padding-top: 10px; /* Align text vertically */
        }

        .add-btn:hover {
            background-color: #0056b3;
        }

        /* Back button styling */
        .back-btn {
            background-color: #6c757d;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            font-size: 16px;
            cursor: pointer;
            margin-bottom: 20px;
            display: inline-block;
            text-decoration: none;
        }

        .back-btn a {
            display: block;
            width: 100%;
            height: 100%;
            text-align: center;
            color: white;
            text-decoration: none;
           ; /* Align text vertically */
        }

        .back-btn:hover {
            background-color: #5a6268;
        }
    </style>
</head>
<body>
    <div class="container">
        <!-- Back button at the top of the container -->
        <button class="back-btn"><a href="../index.html">Back to Home</a></button>


        <h1>Faculty List</h1>

        <table>
            <thead>
                <tr>
                    <th>S.No</th>
                    <th>Name</th>
                    <th>Department</th>
                    <th>Faculty Username</th>
                    <th>Faculty Password</th>
                    <th>Option</th>
                </tr>
            </thead>
            <tbody>
                <?php
                    $connection = mysqli_connect("localhost", "root", "");
                    $db = mysqli_select_db($connection, "new_pro");

                    $sql = "SELECT * FROM faculty_page";
                    $run = mysqli_query($connection, $sql);
                    $id = 1;

                    while ($row = mysqli_fetch_array($run)) {
                        $uid = $row['id'];
                        $name = $row['name'];
                        $department = $row['department'];
                        $faculty_log = $row['faculty_log'];
                        $faculty_pass = $row['faculty_pass'];
                ?>
                <tr>
                    <td><?php echo $id; ?></td>
                    <td><?php echo $name; ?></td>
                    <td><?php echo $department; ?></td>
                    <td><?php echo $faculty_log; ?></td>
                    <td><?php echo $faculty_pass; ?></td>
                    <td class="buttons">
                        <button class="btn btn-success"><a href="edit.php?edit=<?php echo $uid; ?>">Edit</a></button>
                        <button class="btn btn-danger"><a href="delete.php?del=<?php echo $uid; ?>">Delete</a></button>
                    </td>
                </tr>
                <?php $id++; } ?>
            </tbody>
        </table>

        <!-- Add New Button at the bottom inside the box -->
        <button class="add-btn"><a href="add.php">Add New</a></button>
    </div>
</body>
</html>